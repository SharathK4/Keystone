Hi,

Thank for downloading Wolfgang.




NOTE: This demo font is for PERSONAL USE ONLY!

But any donation are very appreciated. 

Paypal account for donation : 
paypal.me/Dessastra



Link to purchase full version and commercial license:

https://crmrkt.com/GK6l7o


If there is a problem, question, or anything about my fonts,

please sent an email to

Doeasembilanpro@yahoo.com

Thanks,


The-sastra Studio